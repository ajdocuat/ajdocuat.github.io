CREATE DATABASE  IF NOT EXISTS `aj_sample_api`;
USE `aj_sample_api`;

DROP TABLE IF EXISTS `tb_product`;
CREATE TABLE `tb_product` (
  `PROD_ID` int(11) NOT NULL AUTO_INCREMENT,
  `PROD_CODE` varchar(100) NOT NULL,
  `PROD_NAME` varchar(200) NOT NULL,
  `PROD_TYPE` varchar(100) DEFAULT NULL,
  `PRICE` decimal(10,0) NOT NULL,
  `INVENTORY` decimal(10,0) DEFAULT NULL,
  `UNIT` varchar(100) DEFAULT NULL,
  `SUPPLIER` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`PROD_ID`),
  UNIQUE KEY `UQ_TB_PRODUCT` (`PROD_CODE`)
) ENGINE=InnoDB;
